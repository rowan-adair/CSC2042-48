-- Clean first draft, just drops schema.
-- second draft
DROP TABLE IF EXISTS LeaseManager;
DROP TABLE IF EXISTS LeaseTenant;
DROP TABLE IF EXISTS Lease;
DROP TABLE IF EXISTS ApartmentManager;
DROP TABLE IF EXISTS ManagerOffice;
DROP TABLE IF EXISTS Office;
DROP TABLE IF EXISTS ApartmentBuilding;
DROP TABLE IF EXISTS Apartment;
DROP TABLE IF EXISTS Building;
DROP TABLE IF EXISTS TechnicianSkill;
DROP TABLE IF EXISTS Skill;
DROP TABLE IF EXISTS Manager;
DROP TABLE IF EXISTS Employee;
DROP TABLE IF EXISTS Tenant;
DROP TABLE IF EXISTS Person;